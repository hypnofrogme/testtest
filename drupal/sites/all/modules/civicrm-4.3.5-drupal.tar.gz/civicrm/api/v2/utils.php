<?php
// $Id: utils.php 40328 2012-05-11 23:06:13Z allen $


if (!function_exists('_civicrm_initialize')) {
  require_once 'api/v2/utils.v2.php';
}

